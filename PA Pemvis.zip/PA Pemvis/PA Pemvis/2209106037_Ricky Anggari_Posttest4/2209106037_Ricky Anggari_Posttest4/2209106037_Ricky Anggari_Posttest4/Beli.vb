﻿Imports MySql.Data.MySqlClient
Imports System.Drawing.Printing

Public Class Beli
   Private hargaCicilan As Integer ' Variabel untuk menyimpan harga cicilan

    Private Sub PrintDocument1_PrintPage(sender As Object, e As PrintPageEventArgs) Handles PrintDocument1.PrintPage
        ' Mengatur font
        Dim titleFont As New Font("Arial", 18, FontStyle.Bold)
        Dim subtitleFont As New Font("Arial", 12, FontStyle.Italic)
        Dim bodyFont As New Font("Arial", 12)

        ' Mengatur posisi awal pencetakan
        Dim yPos As Single = 100

        ' Menambahkan judul
        Dim title As String = "Bukti Pembelian Rumah"
        Dim titleSize As SizeF = e.Graphics.MeasureString(title, titleFont)
        Dim titleX As Single = (e.PageBounds.Width - titleSize.Width) / 2 ' Pusat judul
        e.Graphics.DrawString(title, titleFont, Brushes.Black, titleX, yPos)
        yPos += titleSize.Height + 20 ' Menambahkan padding setelah judul

        ' Menambahkan subjudul
        Dim subtitle As String = "Detail Pembelian:"
        e.Graphics.DrawString(subtitle, subtitleFont, Brushes.Black, 100, yPos)
        yPos += subtitleFont.Height + 10 ' Menambahkan padding setelah subjudul

        ' Menambahkan detail pembelian
        Dim alamat As String = "Alamat: " & TextBox1.Text
        Dim nama As String = "Nama: " & TextBox2.Text
        Dim nik As String = "NIK: " & TextBox3.Text
        Dim cicilan As String = "Cicilan per Bulan: " & hargaCicilan.ToString() ' Menggunakan hargaCicilan yang telah dihitung sebelumnya

        e.Graphics.DrawString(alamat, bodyFont, Brushes.Black, 100, yPos)
        yPos += bodyFont.Height ' Menggeser posisi untuk baris berikutnya
        e.Graphics.DrawString(nama, bodyFont, Brushes.Black, 100, yPos)
        yPos += bodyFont.Height
        e.Graphics.DrawString(nik, bodyFont, Brushes.Black, 100, yPos)
        yPos += bodyFont.Height
        e.Graphics.DrawString(cicilan, bodyFont, Brushes.Black, 100, yPos)
    End Sub



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            ' Mendapatkan nilai dari input pengguna
            Dim alamat As String = TextBox1.Text
            Dim nama As String = TextBox2.Text
            Dim nik As String = TextBox3.Text
            Dim cicilan As Integer = Integer.Parse(TextBox4.Text) ' TextBox4 adalah textbox yang berisi nilai cicilan

            If String.IsNullOrEmpty(alamat) OrElse String.IsNullOrEmpty(nama) OrElse String.IsNullOrEmpty(nik) Then
                MsgBox("Harap isi semua field yang diperlukan.")
                Return
            End If

            ' Buka koneksi database
            koneksi()

            Dim insertQuery As String = "INSERT INTO beli (alamat, nama, nik, cicilan) VALUES (@alamat, @nama, @nik, @cicilan)"
            Using command As New MySqlCommand(insertQuery, CONN)
                command.Parameters.AddWithValue("@alamat", alamat)
                command.Parameters.AddWithValue("@nama", nama)
                command.Parameters.AddWithValue("@nik", nik)
                command.Parameters.AddWithValue("@cicilan", cicilan)
                command.ExecuteNonQuery() ' Eksekusi perintah SQL
            End Using

            Dim hargaRumah As Integer = 0
            Dim queryHarga As String = "SELECT harga FROM rumah"
            Using cmdHarga As New MySqlCommand(queryHarga, CONN)
                hargaRumah = Convert.ToInt32(cmdHarga.ExecuteScalar())
            End Using

            ' Menghapus rumah dari database
            Dim deleteQuery As String = "DELETE FROM rumah WHERE alamat = @alamat"
            Using command As New MySqlCommand(deleteQuery, CONN)
                command.Parameters.AddWithValue("@alamat", alamat)
                Dim rowsAffected As Integer = command.ExecuteNonQuery()

                If rowsAffected = 0 Then
                    MsgBox("Alamat yang dimasukkan tidak ditemukan dalam database.")
                    Return
                End If
            End Using


            ' Menghitung harga rumah dibagi dengan cicilan
            hargaCicilan = hargaRumah / cicilan

            MsgBox("Rumah berhasil dibeli. Harga cicilan per bulan: " & hargaCicilan.ToString())

            ' Siapkan Print Preview Dialog
            PrintPreviewDialog1.Document = PrintDocument1
            PrintPreviewDialog1.ShowDialog()

        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        Finally
            If CONN IsNot Nothing AndAlso CONN.State = ConnectionState.Open Then
                CONN.Close()
            End If
            tampilJenis()

        End Try
    End Sub


    Sub tampilJenis()
        DA = New MySqlDataAdapter("SELECT * from rumah", CONN)
        DS = New DataSet
        DS.Clear()
        DA.Fill(DS, "rumah")
        DataGridView1.DataSource = DS.Tables("rumah")
        DataGridView1.Refresh()
    End Sub
    Private Sub TampilkanDatarumah()

        Dim command As New MySqlCommand("SELECT * FROM rumah", CONN)

        Dim adapter As New MySqlDataAdapter(command)

        Dim table As New DataTable()

        adapter.Fill(table)

        DataGridView1.DataSource = table


        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        DataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter


    End Sub
    Private Sub TextBox4_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox4.KeyPress
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub Beli_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        koneksi()
        TampilkanDatarumah()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
        Login.Show()

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub
End Class