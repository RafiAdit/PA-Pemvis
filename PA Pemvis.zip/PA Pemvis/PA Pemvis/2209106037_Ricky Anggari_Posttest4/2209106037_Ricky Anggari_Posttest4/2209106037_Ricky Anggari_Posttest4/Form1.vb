﻿Imports MySql.Data.MySqlClient
Public Class Form1
     
    Sub tampilJenis()
        DA = New MySqlDataAdapter("SELECT * from rumah", CONN)
        DS = New DataSet
        DS.Clear()
        DA.Fill(DS, "rumah")
        DataGridView1.DataSource = DS.Tables("rumah")
        DataGridView1.Refresh()
    End Sub
    
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        koneksi()
        TampilkanDatarumah()
    End Sub
    

    Private Sub TampilkanDatarumah()

        Dim command As New MySqlCommand("SELECT * FROM rumah", CONN)

        Dim adapter As New MySqlDataAdapter(command)

        Dim table As New DataTable()

        adapter.Fill(table)

        DataGridView1.DataSource = table


        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        DataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter


    End Sub

   Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Then
            MsgBox("Jangan Dikosongkan")
        ElseIf TextBox1.Text <= 0 Then
            MsgBox("Tidak boleh 0 atau minus")
        ElseIf TextBox3.Text <= 0 Then
            MsgBox("Tidak boleh 0 atau minus")
        ElseIf ComboBox1.Text = "" Then
            MsgBox("Jangan Dikosongkan")
        ElseIf RadioButton1.Checked = False AndAlso RadioButton2.Checked = False Then
            MsgBox("Jangan Dikosongkan")
        ElseIf Not (CheckBox1.Checked Or CheckBox2.Checked Or CheckBox3.Checked Or CheckBox4.Checked Or CheckBox5.Checked Or CheckBox6.Checked) Then
            MsgBox("Pilih Prabotan")
        End If

        Try
            koneksi()
            Dim harga As Integer = Integer.Parse(TextBox3.Text)
            Dim Halaman As String = If(RadioButton1.Checked, RadioButton1.Text, RadioButton2.Text)
            Dim prabotan As String = ""
            For Each cb As CheckBox In GroupBox1.Controls.OfType(Of CheckBox)()
                If cb.Checked Then
                    prabotan &= cb.Text & ", "
                End If
            Next
            prabotan = prabotan.TrimEnd(", ")
            Dim tanggal As String = DateTimePicker1.Value.ToString("yyyy-MM-dd")
            Dim query As String = "INSERT INTO rumah (alamat, tipe, halaman, tanggal, prabotan, harga) VALUES (@alamat, @tipe, @halaman, @tanggal, @prabotan, @harga)"

            Using command As New MySqlCommand(query, CONN)
                command.Parameters.AddWithValue("@alamat", TextBox1.Text)
                command.Parameters.AddWithValue("@tipe", ComboBox1.Text)
                command.Parameters.AddWithValue("@halaman", Halaman)
                command.Parameters.AddWithValue("@tanggal", tanggal)
                command.Parameters.AddWithValue("@prabotan", prabotan)
                command.Parameters.AddWithValue("@harga", harga)
                command.ExecuteNonQuery()
            End Using

            MsgBox("Simpan Data Sukses!")
        Catch ex As MySqlException
            MsgBox("Error simpan data: " & ex.Message)
        Finally
            If CONN IsNot Nothing AndAlso CONN.State = ConnectionState.Open Then
                CONN.Close()
            End If
            tampilJenis()
        End Try
    End Sub


    Private Sub Hapus_Click(sender As Object, e As EventArgs) Handles Hapus.Click
        If TextBox1.Text = Nothing Then
            MsgBox("Alamat yang akan dihapus belum diisi")
            TextBox1.Focus()
        Else
            Try
                koneksi()
                Dim deleteQuery As String = "DELETE FROM rumah WHERE alamat = @alamat"

                Using command As New MySqlCommand(deleteQuery, CONN)
                    command.Parameters.AddWithValue("@alamat", TextBox1.Text)
                    command.ExecuteNonQuery()
                End Using

                MsgBox("Data berhasil dihapus")
                TampilkanDatarumah()

            Catch ex As Exception
                MsgBox("Error: " & ex.Message)
            Finally
                If CONN IsNot Nothing AndAlso CONN.State = ConnectionState.Open Then
                    CONN.Close()
                End If
            End Try
        End If
    End Sub

    Private Sub Ubah_Click(sender As Object, e As EventArgs) Handles Ubah.Click
        If TextBox1.Text = "" Then
            MsgBox("Alamat belum diisi")
            TextBox1.Focus()
            Return
        End If

        Try
            koneksi()
            Dim updateQuery As String = "UPDATE rumah SET tipe = @tipe, halaman = @halaman, tanggal = @tanggal, prabotan = @prabotan, harga = @harga WHERE alamat = @alamat"

            Using command As New MySqlCommand(updateQuery, CONN)
                command.Parameters.AddWithValue("@alamat", TextBox1.Text)
                command.Parameters.AddWithValue("@halaman", If(RadioButton1.Checked, RadioButton1.Text, RadioButton2.Text))
                command.Parameters.AddWithValue("@tanggal", DateTimePicker1.Value.Date)
                command.Parameters.AddWithValue("@tipe", ComboBox1.Text)
                command.Parameters.AddWithValue("@harga", TextBox3.Text)

                Dim prabotan As String = ""
                For Each cb As CheckBox In GroupBox1.Controls.OfType(Of CheckBox)()
                    If cb.Checked Then
                        prabotan &= cb.Text & ", "
                    End If
                Next
                prabotan = prabotan.TrimEnd(", ")
                command.Parameters.AddWithValue("@prabotan", prabotan)

                command.ExecuteNonQuery()
            End Using

            MsgBox("Data berhasil diubah")
            TampilkanDatarumah()

        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        Finally
            If CONN IsNot Nothing AndAlso CONN.State = ConnectionState.Open Then
                CONN.Close()
            End If
        End Try
    End Sub



    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        Dim searchText As String = TextBox2.Text.Trim()

        If searchText <> "" Then
            Try
                koneksi()
                Dim query As String = "SELECT * FROM rumah WHERE alamat LIKE '%" & searchText & "%'"
                CMD = New MySqlCommand(query, CONN)
                RD = CMD.ExecuteReader()

                Dim dt As New DataTable
                dt.Load(RD)

                DataGridView1.DataSource = dt

                DataGridView1.ReadOnly = True

                DataGridView1.Rows.Clear()

                For Each dr As DataRow In dt.Rows
                    DataGridView1.Rows.Add(dr.ItemArray)
                Next

            Catch ex As Exception
            End Try

        Else
            TampilkanDatarumah()
        End If
    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        ComboBox1.SelectedIndex = -1
        RadioButton1.Checked = False
        RadioButton2.Checked = False
        For Each cb As CheckBox In GroupBox1.Controls.OfType(Of CheckBox)()
            cb.Checked = False
        Next
        DateTimePicker1.Value = DateTime.Now
    End Sub

 

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            ' Jika bukan angka, abaikan input dan tandai sebagai sudah ditangani (handled)
            e.Handled = True
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        History.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
        Login.Show()
    End Sub


End Class


