﻿Imports MySql.Data.MySqlClient
Public Class History
 

    Private Sub TampilkanHistory()

        Dim command As New MySqlCommand("SELECT * FROM beli", CONN)

        Dim adapter As New MySqlDataAdapter(command)

        Dim table As New DataTable()

        adapter.Fill(table)

        DataGridView1.DataSource = table


        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        DataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter


    End Sub
    Private Sub History_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        koneksi()
        TampilkanHistory()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        Form1.Show()

    End Sub
End Class