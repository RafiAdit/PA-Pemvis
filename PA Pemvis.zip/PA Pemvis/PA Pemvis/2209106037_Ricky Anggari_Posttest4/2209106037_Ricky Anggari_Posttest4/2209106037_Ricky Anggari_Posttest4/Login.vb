﻿Imports MySql.Data.MySqlClient
Public Class Login
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Register.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            ' Memanggil fungsi koneksi() untuk membuka koneksi ke MySQL
            koneksi()
            If TextBox1.Text = "admin" AndAlso TextBox2.Text = "admin" Then
                MessageBox.Show("Login berhasil sebagai admin!")
                Form1.Show()
            Else
                Dim query As String = "SELECT COUNT(*) FROM login WHERE Username = @Username AND Password = @Password"
                CMD = New MySqlCommand(query, CONN)
                CMD.Parameters.AddWithValue("@Username", TextBox1.Text)
                CMD.Parameters.AddWithValue("@Password", TextBox2.Text)

                Dim result As Integer = Convert.ToInt32(CMD.ExecuteScalar())
                If result > 0 Then
                    MessageBox.Show("Login berhasil!")
                    Beli.Show()
                Else
                    MessageBox.Show("Login gagal. Nama pengguna atau kata sandi salah.")
                End If
            End If

            CONN.Close()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        End Try
    End Sub

     
End Class