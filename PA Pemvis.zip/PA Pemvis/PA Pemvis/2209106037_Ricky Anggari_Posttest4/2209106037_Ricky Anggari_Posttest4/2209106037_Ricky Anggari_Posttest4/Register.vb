﻿Imports MySql.Data.MySqlClient
Public Class Register

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim username As String = TextBox1.Text
        Dim password As String = TextBox2.Text

        If String.IsNullOrEmpty(username) OrElse String.IsNullOrEmpty(password) Then
            MessageBox.Show("Username dan password tidak boleh kosong.")
            Return
        End If

        If username = "admin" AndAlso password = "admin" Then
            MessageBox.Show("Tidak bisa mendaftar dengan username 'admin'.")
            Return
        End If

        If IsUsernameExists(username) Then
            MessageBox.Show("Username sudah digunakan. Silakan pilih username lain.")
            Return
        End If
        Try
            koneksi()
            CMD = New MySqlCommand("INSERT INTO login (Username, Password) VALUES (@username, @password)", CONN)
            CMD.Parameters.AddWithValue("@username", username)
            CMD.Parameters.AddWithValue("@password", password)
            Dim rowsAffected As Integer = CMD.ExecuteNonQuery
            If rowsAffected > 0 Then
                MessageBox.Show("Registrasi berhasil! Silakan login.")
                Me.Hide()
                Login.Show()
            Else
                MessageBox.Show("Registrasi gagal. Tidak ada baris yang terpengaruh.")
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            CONN.Close()
        End Try
    End Sub


    Private Function IsUsernameExists(username As String) As Boolean
        ' Mengecek apakah username sudah digunakan sebelumnya dalam database
        Dim query As String = "SELECT COUNT(*) FROM login WHERE Username = @Username"
        Using connection As New MySqlConnection(STR)
            Using command As New MySqlCommand(query, connection)
                command.Parameters.AddWithValue("@Username", username)
                Dim count As Integer
                Return count > 0
            End Using
        End Using
    End Function

    Private Sub Register_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        Login.Show()
    End Sub
End Class